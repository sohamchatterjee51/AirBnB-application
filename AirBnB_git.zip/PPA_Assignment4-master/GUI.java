    import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*; 

/**
 * The main GUI class that handles all GUI elements & the core application window (e.g. navigation panel) 
 * @author Muhsin Kumbay, Soham Chatterjee, Rahul Patel, Mishal Almazidi
 */
    
public class GUI {
    private JFrame frame; 
    private final int MAX_WIDTH = 768; 
    private final int MAX_HEIGHT = 705; 
    
    private JPanel cards, contentPane, navPanel, pricePanel;
    private JPanel cardMap, cardStatistics;
    
    private JComboBox fromComboBox, toComboBox;
    private JButton moveLeftButton, moveRightButton; 
    
    private WelcomeScreen welcomeScreen;
    private StatisticScreen statScreen;
    private MapImage mapScreen;
    private InfoScreen infoScreen; 
    
    private boolean initialSetup; 
    
    private int toPrice, fromPrice; 
    
    /**
     * Constructor for GUI 
     */
    public GUI() {
        welcomeScreen = new WelcomeScreen();
        initialSetup = false;
        setupGUI(MAX_WIDTH, MAX_HEIGHT); 
    }
    
    /**
     * Create the basic GUI
     */
    private void setupGUI(int maxWidth, int maxHeight) {
        //Create and set up the window.
        frame = new JFrame("London Property Marketplace");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 
        //Add components to the windows 
        addComponents(frame.getContentPane()); 
 
        //Display the window.
        frame.pack();
        frame.setSize(maxWidth, maxHeight); 
        frame.setVisible(true);
    }   
    
    /**
     * Adds componenets to GUI
     * @param content pane 
     */
    private void addComponents(Container pane) {
        contentPane = (JPanel)pane; 
        
        // Specify the layout manager with nice spacing 
        contentPane.setLayout(new BorderLayout(6, 6)); // border layout with spacing
      
        // Create new panel to contain price selection components 
        pricePanel = new JPanel();
        pricePanel.setLayout(new FlowLayout(FlowLayout.RIGHT)); 
        
        fromComboBox = new JComboBox();
        toComboBox = new JComboBox(); 
        
        // Add price range to comboboxes 
        for(int i = 0; i <= 30; i++) {
            fromComboBox.addItem(new Integer(i*30));
            toComboBox.addItem(new Integer(i*30));
        }
        
        pricePanel.add(new JLabel("From: ")); 
        pricePanel.add(fromComboBox);
        pricePanel.add(new JLabel("To: ")); 
        pricePanel.add(toComboBox); 
        
        // Sets the sizes of the combo boxes to 100 by 300.
        fromComboBox.setPreferredSize(new Dimension(100, 30));
        toComboBox.setPreferredSize(new Dimension(100, 30));
        
        // Adds an action listener to price selection combo boxes:
        toComboBox.addActionListener((ActionEvent ev) -> {updatePrice();});
        fromComboBox.addActionListener((ActionEvent ev) -> {updatePrice();});
        
        // Adds an etched border around the panel. 
        pricePanel.setBorder(new EtchedBorder());
        
        // Creates new panel to contain navigation buttons 
        navPanel = new JPanel(); 
        navPanel.setLayout(new BorderLayout()); 
        
        // Creates buttons 
        moveLeftButton = new JButton("<"); 
        moveRightButton = new JButton(">"); 
        
        moveLeftButton.setEnabled(false);
        moveRightButton.setEnabled(false);
        
        moveRightButton.addActionListener((ActionEvent ev) -> {moveRight();});
        moveLeftButton.addActionListener((ActionEvent ev) -> {moveLeft();});
       
        navPanel.add(moveLeftButton, BorderLayout.WEST); // Add to west of panel
        navPanel.add(moveRightButton, BorderLayout.EAST); // Add to east of panel
        
        navPanel.setBorder(new EtchedBorder()); 
        
        // Add various panels to main panel
        contentPane.add(pricePanel, BorderLayout.NORTH);
        contentPane.add(navPanel, BorderLayout.SOUTH);
        
        cards = new JPanel(new CardLayout()); 
      
        cards.add(welcomeScreen.getPanel(), welcomeScreen.getPanel().getName());
        
        contentPane.add(cards, BorderLayout.CENTER);
    }
    
    /**
     * Move one panel to the right
     */ 
    private void moveRight() 
    {
        CardLayout c1 = (CardLayout)(cards.getLayout()); 
        c1.next(cards);
    }
    
    /**
     * Move one panel to the left
     */ 
    private void moveLeft() 
    {
        CardLayout c1 = (CardLayout)(cards.getLayout()); 
        c1.previous(cards);  
    }
    
    /**
     * Updates the selected price range
     */
    private void updatePrice() 
    {
        fromPrice = (Integer)fromComboBox.getSelectedItem(); 
        toPrice = (Integer)toComboBox.getSelectedItem(); 
        
        if (toPrice >= fromPrice && toPrice >= 0) {
            welcomeScreen.updatePriceText(fromPrice, toPrice); 
            moveLeftButton.setEnabled(true);
            moveRightButton.setEnabled(true);
            if (!initialSetup) {
                setupOtherScreen();
                initialSetup = true;
            }
            else {
                mapScreen.setPrice(fromPrice, toPrice);
                statScreen.updateText(fromPrice, toPrice);
            }
        }
        else if (fromPrice > toPrice && toPrice != 0){
            JOptionPane.showMessageDialog(frame, "Invalid price range!"); 
            fromPrice = 0; 
            toPrice = 0;
        }
    }
    
    /**
     * Sets up the other screens/panels. 
     */
    private void setupOtherScreen()
    {
        Statistics tempStat = new Statistics(fromPrice, toPrice);
        
        statScreen = new StatisticScreen(tempStat);
        mapScreen = new MapImage(fromPrice, toPrice);
        infoScreen = new InfoScreen(); 
        
        cards.add(mapScreen.getPanel(), mapScreen.getPanel().getName()); 
        cards.add(statScreen.getPanel(), statScreen.getPanel().getName()); 
        cards.add(infoScreen.getPanel(), infoScreen.getPanel().getName()); 
        
        contentPane.add(cards, BorderLayout.CENTER);
        
        contentPane.revalidate(); 
        contentPane.repaint();
    }
}