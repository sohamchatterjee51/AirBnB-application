

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class StatsTest
 *
 * @author Muhsin Kumbay, Soham Chatterjee, Rahul Patel, Mishal Almazidi
 * @version 28/03/18
 */
public class StatsTest
{
    /**
     * Default constructor for test class GUITest
     */
    public StatsTest()
    {
    } 

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    @Test
    public void testStatistics()
    {
        Statistics stats = new Statistics(0, 300); 
        String expensiveNeighbourhood = "City of London"; 
        int averageAvail = 155; 
        int averageNights = 3; 
        
        assertEquals(expensiveNeighbourhood, stats.mostExpensiveNeighbourhood());
        assertEquals(averageAvail, stats.averageAvailability());
        assertEquals(averageNights, stats.averageNumberOfNight());
    }
}


