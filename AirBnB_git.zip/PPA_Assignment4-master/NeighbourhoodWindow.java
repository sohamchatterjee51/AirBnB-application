import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*; 
import java.util.*;
import static java.util.Comparator.comparing; 
    
/**
 * Returns all the listings in a speicified neighbourhood in a seperate window within a 
 * specific price range. Users can navigate through these listings, and order them 
 * by host name and price. 
 * 
 * @author Muhsin Kumbay, Soham Chatterjee, Rahul Patel, Mishal Almazidi
 * @version 21/03/18
 */
public class NeighbourhoodWindow
{
    private Statistics stats; 
    private JPanel contentPane; 
    private JTextArea textDisplay;
    private JComboBox sortByBox;
    private String neighbourhood;
    private int index, maxIndex;
    private ArrayList<AirbnbListing> listings; 
    private JButton moveLeftButton, moveRightButton; 
    private String[] orderOptions; 
    private JLabel sortByText;
    
    /**
     * Constructor for objects of class NeighbourhoodWindow
     */
    public NeighbourhoodWindow(String neighbourhood, int minPrice, int maxPrice)
    {
        if (minPrice > maxPrice) {
            minPrice = maxPrice; 
        }
        
        this.neighbourhood = neighbourhood;
        
        stats = new Statistics(minPrice, maxPrice); 
        
        JFrame frame = new JFrame(neighbourhood); 
        
        listings = stats.getNeighbourhoodListings(this.neighbourhood);
        maxIndex = listings.size() - 1;
        orderOptions = new String[] {"Price", "Alphabetically by host name", "Number of reviews"};
        
        //Add componenets
        addComponents(frame.getContentPane());
        
        //Display the window.
        frame.pack();
        frame.setSize(425, 200);
        frame.setResizable(false);
        frame.setVisible(true);      
    }
    
    /**
     * Adds componenets to the window. 
     */
    private void addComponents(Container pane) 
    {
        contentPane = (JPanel)pane;  
        contentPane.setLayout(new BorderLayout());
        
        // Creates text display
        textDisplay = new JTextArea(5, 1);
        textDisplay.setText(listings.get(index).toString());
        textDisplay.setEditable(false);
        textDisplay.setBorder(new EtchedBorder()); 
        
        // Sorting panel 
        JPanel sortingPanel = new JPanel(new BorderLayout()); 
        
        sortByBox = new JComboBox(orderOptions);
        sortByBox.setPreferredSize(new Dimension(300, 25));
        sortByText = new JLabel("Sort by: "); 
        
        sortByBox.addActionListener((ActionEvent ev) -> {sortBy();});
        
        sortingPanel.add(sortByBox, BorderLayout.EAST); 
        sortingPanel.add(sortByText, BorderLayout.WEST); 
        
        // Creates buttons 
        JPanel buttonPanel = new JPanel(new BorderLayout());
        
        moveLeftButton = new JButton("<"); 
        moveRightButton = new JButton(">"); 
        
        moveLeftButton.addActionListener((ActionEvent ev) -> {movePreviousListing();});
        moveRightButton.addActionListener((ActionEvent ev) -> {moveNextListing();});
        
        buttonPanel.add(moveLeftButton, BorderLayout.WEST);
        buttonPanel.add(moveRightButton, BorderLayout.EAST);
        
        contentPane.add(textDisplay, BorderLayout.CENTER);
        contentPane.add(sortingPanel, BorderLayout.NORTH);
        contentPane.add(buttonPanel, BorderLayout.SOUTH);
    }
    
    /**
     * Moves to the next listing
     */
    private void moveNextListing() 
    {
        if (index < maxIndex) {
            index++;
            textDisplay.setText(listings.get(index).toString());
        }
    }
    
    /**
     * Moves to the previous listing
     */
    private void movePreviousListing() 
    {
        if (index > 0) {
            index--;
            textDisplay.setText(listings.get(index).toString());
        }
    }
    
    /**
     * Orders the listings by specific categories
     */
    private void sortBy()
    {
        String selectedItem = String.valueOf(sortByBox.getSelectedItem()); 
        
        if (selectedItem.equals(orderOptions[0])) { // sort by price
            Collections.sort(listings, comparing(AirbnbListing::getPrice));
        }
        else if (selectedItem.equals(orderOptions[1])) { // sort by name
            Collections.sort(listings, comparing(AirbnbListing::getHost_name));
        }
        else if (selectedItem.equals(orderOptions[2])) { // sort by number of reviews
            Collections.sort(listings, comparing(AirbnbListing::getNumberOfReviews));
        }
        
        index = 0; 
        textDisplay.setText(listings.get(index).toString());
    }
}
