import java.awt.*;
import javax.swing.*;
import java.util.*; 

/**
 * Contains a map of London and pins in each neighbourhood. 
       
 * @author Muhsin Kumbay, Soham Chatterjee, Rahul Patel, Mishal Almazidi
 * @version 27/03/18
 */
 
public class MapImage

{
  // instance variables - replace the example below with your own
  private JLayeredPane cardMap;
  private JLabel mapLabel;
  private Pin pin, pin2;
  private int fromPrice, toPrice; 
  private ArrayList<Pin> pins; 
  
  /**
   * Constructor for objects of class Map
   */
     
   public MapImage(int price1, int price2)
   {
        fromPrice = price1; 
        toPrice = price2;

        pins = new ArrayList<>(); 
        
        cardMap = new JLayeredPane();
        
        cardMap.setPreferredSize(new Dimension(768, 593)); 
        
        mapLabel = new JLabel();
        mapLabel.setIcon(new ImageIcon("Map/Map.jpg"));


        //Locations of every pin Aplhabetically  
        pins.add(new Pin("Barking and Dagenham", 555, 180, fromPrice, toPrice));
        pins.add(new Pin("Barnet", 260, 80, fromPrice, toPrice));
        pins.add(new Pin("Bexley", 580, 290, fromPrice, toPrice));
        pins.add(new Pin("Brent", 210, 160, fromPrice, toPrice));
        pins.add(new Pin("Bromley", 500, 405, fromPrice, toPrice));
        pins.add(new Pin("Camden", 305, 175, fromPrice, toPrice));
        pins.add(new Pin("City of London", 370, 250, fromPrice, toPrice));
        pins.add(new Pin("Croydon", 360, 400, fromPrice, toPrice));
        pins.add(new Pin("Ealing", 165, 210, fromPrice, toPrice));
        pins.add(new Pin("Enfield", 375, 90, fromPrice, toPrice));
        pins.add(new Pin("Greenwich", 485, 330, fromPrice, toPrice));
        pins.add(new Pin("Hackney", 400, 175, fromPrice, toPrice));
        pins.add(new Pin("Hammersmith and Fulham", 245, 230, fromPrice, toPrice));
        pins.add(new Pin("Haringey", 350, 120, fromPrice, toPrice));
        pins.add(new Pin("Harrow", 150, 105, fromPrice, toPrice));
        pins.add(new Pin("Havering", 620, 110, fromPrice, toPrice));
        pins.add(new Pin("Hillingdon", 90, 150, fromPrice, toPrice));
        pins.add(new Pin("Hounslow", 150, 300, fromPrice, toPrice));
        pins.add(new Pin("Islington", 345, 175, fromPrice, toPrice));
        pins.add(new Pin("Kensington and Chelsea", 285, 270, fromPrice, toPrice));
        pins.add(new Pin("Kingston upon Thames", 205, 380, fromPrice, toPrice));
        pins.add(new Pin("Lambeth", 350, 360, fromPrice, toPrice));
        pins.add(new Pin("Lewisham", 435, 315, fromPrice, toPrice));
        pins.add(new Pin("Merton", 270, 365, fromPrice, toPrice));
        pins.add(new Pin("Newham", 480, 200, fromPrice, toPrice));
        pins.add(new Pin("Redbridge", 510, 175, fromPrice, toPrice));
        pins.add(new Pin("Richmond upon Thames", 195, 325, fromPrice, toPrice));
        pins.add(new Pin("Southwark", 380, 325, fromPrice, toPrice));
        pins.add(new Pin("Sutton", 270, 440, fromPrice, toPrice));
        pins.add(new Pin("Tower Hamlets", 420, 260, fromPrice, toPrice));
        pins.add(new Pin("Waltham Forest", 425, 110, fromPrice, toPrice));
        pins.add(new Pin("Wandsworth", 315, 360, fromPrice, toPrice));
        pins.add(new Pin("Westminster", 290, 230, fromPrice, toPrice));
        
        
        // Add components to the panel. 
        for (Pin pin : pins) {
            cardMap.add(pin.getImage(), 2, 0);
        }
        
        cardMap.add(mapLabel, 1, 0);
        
        mapLabel.setBounds(0, 0, 768, 593);
   }

  // Returns the JLayeredPane cardMap.
  public JLayeredPane getPanel()
   {
        return cardMap;
   }
  
  /**
   * Updates the price range.
   * @param minimum price, maximum price. 
   */
  public void setPrice(int price1, int price2) 
  {
      fromPrice = price1; 
      toPrice = price2;
      for (Pin pin : pins) {
          pin.setPrice(fromPrice, toPrice);
      }
  }
    
}
