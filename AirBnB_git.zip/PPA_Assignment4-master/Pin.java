import javax.swing.JLabel;
import java.awt.Dimension;
import javax.swing.ImageIcon;
import javax.swing.*;
import java.awt.*;
import java.awt.image.*;
import javax.imageio.*;
import java.io.*; 
import java.awt.event.*;


/**
 * A representation of a pin. Clicking on a pin opens a new window providing information of the 
 * associated neighbourhood. 
 *
 * @author Muhsin Kumbay, Soham Chatterjee, Rahul Patel, Mishal Almazidi
 * @version 25/03/18
 */
public class Pin
{
    private JLabel pin;
    private Statistics stats; 
    private String neighbourhood;
    private NeighbourhoodWindow neighbourWindow;
    private int minPrice, maxPrice; 
    private ImageIcon pinImage; 
    private int xPos, yPos; 
    
    /**
     * Constructor for objects of class Pin
     */
    public Pin(String neighbourhood, int x, int y, int fromPrice, int toPrice)
    {
        minPrice = fromPrice;
        maxPrice = toPrice; 
        
        xPos = x; 
        yPos = y; 
        
        stats = new Statistics(fromPrice, toPrice); 
        
        int imageScaler = stats.amountHousesNeighbourhood(neighbourhood) / 650;
        
        pinImage = new ImageIcon("Map/Pin.png"); // load the image to a imageIcon
        Image image = pinImage.getImage(); // transform it 
        Image newimg = image.getScaledInstance(20 + imageScaler, 20 + imageScaler,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
        pinImage = new ImageIcon(newimg);  // transform it back
        
        pin = new JLabel();
        pin.setIcon(pinImage);
        pin.setBounds(xPos, yPos, 20 + imageScaler, 20 + imageScaler);
        
        pin.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                neighbourWindow = new NeighbourhoodWindow(neighbourhood, minPrice, maxPrice);
            }
        });
    }
    
    /**
     * Returrns the pin JLabel
     */
    public JLabel getImage()
    {
        return pin;
    }
    
    /**
     * Updates the price range
     */
    public void setPrice(int price1, int price2) 
    {
        minPrice = price1; 
        maxPrice = price2;
    }
}

