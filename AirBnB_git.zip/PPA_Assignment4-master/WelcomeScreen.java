import javax.swing.UIManager.LookAndFeelInfo;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import javax.swing.border.Border;
import javax.swing.*;

/**
 * Displays basic instructions to users & displays currently selected price range. 
 * 
 * @author Muhsin Kumbay, Soham Chatterjee, Rahul Patel, Mishal Almazidi
 * @version 27/03/18
 */
public class WelcomeScreen
{
    private JPanel cardWelcome;
    private JLabel welcomeLabel;
    private JLabel instructionsLabel;
    private JTextArea instructionsText;
    private JLabel priceFromLabel;
    private JLabel priceToLabel;

    /**
     * Constructor for objects of class WelcomeScreen
     */
    public WelcomeScreen()
    {
        createPanel();
    }
    
    public void createPanel() 
    {
        cardWelcome = new JPanel(new GridLayout(0, 1)); 
        //create components
        welcomeLabel = new JLabel("Welcome to London Property Marketplace!", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("sansserif",0,18));
        welcomeLabel.setBackground(new Color(214,217,223));
        welcomeLabel.setForeground(new Color(0,0,0));
        
        Font f = welcomeLabel.getFont();
        welcomeLabel.setFont(f.deriveFont(f.getStyle() ^ Font.BOLD));
        
        instructionsLabel = new JLabel("Instructions: ", SwingConstants.CENTER);
        instructionsLabel.setForeground(new Color(0,0,0));
        instructionsLabel.setEnabled(false);
        instructionsLabel.setFont(new Font("sansserif",0,14));
            
        f = instructionsLabel.getFont();
        instructionsLabel.setFont(f.deriveFont(f.getStyle() ^ Font.BOLD));
        instructionsLabel.setVisible(true);
        
        instructionsText = new JTextArea(
            "To begin, please select a price range from the above drop down. Once selected, the prices should be visable in the boxes on the right." 
                + "You will then be able to navigate through properties using the arrows below.");   
        instructionsText.setFont(new Font("sansserif",0,14));
        instructionsText.setBackground(new Color(255,255,255));
        instructionsText.setForeground(new Color(0,0,0));
        instructionsText.setEnabled(true);
        instructionsText.setBorder(BorderFactory.createBevelBorder(1));
        instructionsText.setLineWrap(true);
        instructionsText.setWrapStyleWord(true);
        instructionsText.setEditable(false);
    
        priceFromLabel = new JLabel("Selected Price From: ", SwingConstants.CENTER);
        priceFromLabel.setBounds(345,256,200,35);
        priceFromLabel.setBackground(new Color(214,217,223));
        priceFromLabel.setForeground(new Color(0,0,0));
        priceFromLabel.setEnabled(true);
        priceFromLabel.setFont(new Font("sansserif",0,14));
    
        priceToLabel = new JLabel("Selected Price To: ", SwingConstants.CENTER);
        priceToLabel.setBounds(345,291,200,35);
        priceToLabel.setBackground(new Color(214,217,223));
        priceToLabel.setForeground(new Color(0,0,0));
        priceToLabel.setEnabled(true);
        priceToLabel.setFont(new Font("sansserif",0,14));
        
        //add componenets
        cardWelcome.add(welcomeLabel);
        cardWelcome.add(instructionsLabel);
        cardWelcome.add(instructionsText);
        cardWelcome.add(priceFromLabel);
        cardWelcome.add(priceToLabel);
    }
    
    public JPanel getPanel() 
    {
        return cardWelcome; 
    }
    
    /**
     * Updates the price range section of the panel. 
     * @param fromPrice, toPrice
     */
    public void updatePriceText(int fromPrice, int toPrice) 
    {
        priceFromLabel.setText("Selected Price From: £" + fromPrice + " per night");
        priceToLabel.setText("Selected Price To: £" + toPrice + " per night");
    }
}
