import java.util.*; 

/**
 * This class holds and compiles statistics for the provided house data via AirBnB
 *
 * @author Muhsin Kumbay, Soham Chatterjee, Rahul Patel, Mishal Almazidi
 * @version 20/03/18
 */
public class Statistics
{
    private AirbnbDataLoader dataLoader; 
    private HashMap<String, Integer> housesAmount; // Holds the number of houses in each neighbourhood. 
    private int minPrice, maxPrice; // Minimum and maximum prices for all data

    /**
     * Constructor for objects of class Statistics
     */
    public Statistics(int minPrice, int maxPrice)
    {
        dataLoader = new AirbnbDataLoader(); 
        housesAmount = new HashMap<>(); 
        this.minPrice = minPrice; 
        this.maxPrice = maxPrice; 
        addNeighbourhoods();
    }
    
    /**
     * Processes the AirBnB data and adds all neighbourhood names to ArrayList. 
     */
    public void addNeighbourhoods() 
    {
        for (AirbnbListing listing : dataLoader.load()) 
        {
            if (listing.getPrice() >= minPrice && listing.getPrice() <= maxPrice) {
                if (!housesAmount.containsKey(listing.getNeighbourhood())) {
                    housesAmount.put(listing.getNeighbourhood(), 1); 
                }
                else {
                    housesAmount.put(listing.getNeighbourhood(), 
                        housesAmount.get(listing.getNeighbourhood()) + 1);
                }
            }
        }
    }
    
    /**
     * Returns listings of specified neighbourhood
     */
    public ArrayList<AirbnbListing> getNeighbourhoodListings(String neighbourhood) 
    {
        ArrayList<AirbnbListing> tempListings = new ArrayList<>();
        
        for (AirbnbListing listing : dataLoader.load()) 
        {
            if (listing.getNeighbourhood().equals(neighbourhood) && listing.getPrice() >= minPrice && listing.getPrice() <= maxPrice) {
                tempListings.add(listing); 
            }
        }
        
        return tempListings; 
    }
    
    /**
     * Prints out all the neighbourhood and the amount of houses in each one. 
     */
    public void printAmountHouses() 
    {
        System.out.println(housesAmount);
    }
    
    /**
     * Prints out the amount of the houses in a specified neighbourhood 
     * @param String neighbourhood 
     */
    public int amountHousesNeighbourhood(String neighbourhood) 
    {
        return housesAmount.get(neighbourhood);
    }
    
    /**
     * Returns the number of available properties within a specific price range
     */
    public int numberAvailableProperties() 
    {
        int amount = 0 ;
        for (AirbnbListing listing : dataLoader.load()) 
        {
            if (listing.getPrice() >= minPrice && listing.getPrice() <= maxPrice) {
                amount++;
            }
        }   
        return amount; 
    }
    
    /**
     * Returns the average number of reviews for available properties within a specific price range
     */
    public int averageNumberOfReviews()
    {
        int reviews = 0;       
        for (AirbnbListing listing : dataLoader.load()) 
        {
            if (listing.getPrice() >= minPrice && listing.getPrice() <= maxPrice) {
                reviews += listing.getNumberOfReviews();
            }
        }        
        reviews = reviews / numberAvailableProperties();        
        return reviews;
    }
    
    /**
     * Returns the amount of available properties classified as entire rooms/apartments 
     */
    public int amountRoomOrApartment() 
    {
        int amount = 0;        
        for (AirbnbListing listing : dataLoader.load()) 
        {
            if (listing.getPrice() >= minPrice && listing.getPrice() <= maxPrice && listing.getRoom_type().equals("Entire home/apt")) {
                amount++;
            }
        }        
        return amount;
    }
    
    /**
     * Returns the average minmun number of nights
     */
    public int averageNumberOfNight()
    {
        int nights = 0;
        for (AirbnbListing listing : dataLoader.load()) 
        {
            if (listing.getPrice() >= minPrice && listing.getPrice() <= maxPrice) {
                nights += listing.getMinimumNights();
            }
        }        
        nights = nights / numberAvailableProperties();
        return nights;
        
    }
    
    /**
     * Returns the average avalabilty of the listing within the price range
     */
    public int averageAvailability()
    {
        int availability = 0;
        for (AirbnbListing listing : dataLoader.load()) 
        {
            if (listing.getPrice() >= minPrice && listing.getPrice() <= maxPrice) {
                availability += listing.getAvailability365();
            }
        } 
        availability = availability / numberAvailableProperties();
        
        return availability;
        
    }
    
    /**
     * Returns the average latitude of the properties within the price range
     */
     public int averageLatitude()
    {
        int latitude = 0;
        for (AirbnbListing listing : dataLoader.load()) 
        {
            if (listing.getPrice() >= minPrice && listing.getPrice() <= maxPrice) {
                latitude += listing.getLatitude();
            }
        } 
        latitude = latitude / numberAvailableProperties();
        
        return latitude;
        
    }
    
    /**
     * Returns the average longitude of the properties within the price range
     */
     public double averageLongitude()
    {
        double longitude = 0;
        for (AirbnbListing listing : dataLoader.load()) 
        {
            if (listing.getPrice() >= minPrice && listing.getPrice() <= maxPrice) {
                longitude += listing.getLongitude();
            }
        } 
        longitude = longitude / numberAvailableProperties();
        
        return longitude;
        
    }
    public int averagePrice()
    {
        int averageprice = 0;
        for (AirbnbListing listing : dataLoader.load()) 
        {
            if (listing.getPrice() >= minPrice && listing.getPrice() <= maxPrice) {
                averageprice += listing.getPrice();
            }
        } 
        averageprice = averageprice / numberAvailableProperties();
        
        return averageprice;
    }
    
    /**
     * Returns the most expensive neighbourhood within a certain price range
     */
     public String mostExpensiveNeighbourhood()
    {
        HashMap<String, Integer> expensiveNeighbourhood = new HashMap<String, Integer>();
        
        for (AirbnbListing listing : dataLoader.load()) 
        {
            if (listing.getPrice() >= minPrice && listing.getPrice() <= maxPrice) {
                if (!expensiveNeighbourhood.containsKey(listing.getNeighbourhood())) {
                    expensiveNeighbourhood.put(listing.getNeighbourhood(), (listing.getPrice() * listing.getMinimumNights()) / amountHousesNeighbourhood(listing.getNeighbourhood())); 
                }
                else {
                    expensiveNeighbourhood.put(listing.getNeighbourhood(), 
                    expensiveNeighbourhood.get(listing.getNeighbourhood()) + listing.getPrice() * listing.getMinimumNights() / amountHousesNeighbourhood(listing.getNeighbourhood()));
                }
            }            
        }     
        
        String n = Collections.max(expensiveNeighbourhood.entrySet(), Map.Entry.comparingByValue()).getKey();
        
        return n;
    } 
}
