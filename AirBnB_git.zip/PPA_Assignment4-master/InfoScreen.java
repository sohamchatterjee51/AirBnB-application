import java.awt.*;
import javax.swing.*;
import java.util.*; 

import java.net.URL;
import java.net.URI;
import java.io.IOException;
import java.net.URISyntaxException;
import java.awt.event.MouseEvent;
import java.net.MalformedURLException;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseMotionListener;
/**
 * The InfoScreen displays misc. information about AirBnB. 
 * 
 * @author Muhsin Kumbay, Soham Chatterjee, Rahul Patel, Mishal Almazidi
 * @version 27/03/18
 */
public class InfoScreen
{
    private JPanel cardInfo;    
    private URL airbnb;
    private JTextArea airBnBinfo;
    private JLabel airBnBlabel;
    private JLabel airbnbphoto;
    private JLabel link;
    
    /**
     * Constructor for objects of class InfoScreen
     */
    public InfoScreen()
    {
        createPanel(); // Constructs the panel. 
    }
    
    /** 
     * Sets up the panel & adds components to it. 
     */
    private void createPanel() 
    {
        cardInfo = new JPanel(new GridLayout(4, 0, 0, 0)); 
        
        airBnBlabel= new JLabel("About AirBnB: ", SwingConstants.CENTER);
        airBnBlabel.setEnabled(false);
        airBnBlabel.setFont(new Font("sansserif",0,18));
        airBnBlabel.setForeground(Color.black);
        
        Font f = airBnBlabel.getFont();
        airBnBlabel.setFont(f.deriveFont(f.getStyle() ^ Font.BOLD));
        
        link = new JLabel("Click here to open AirBnB website in new window(i.e. default browser)", SwingConstants.CENTER);
        link.setForeground(Color.blue);
        link.setFont(new Font("sansserif",0,16));
        link.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        link.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent e){   
                try{
                    Desktop desktop = java.awt.Desktop.getDesktop();
                    URI airbnbsite = new URI("https://www.airbnb.co.uk/");
                    desktop.getDesktop().browse(airbnbsite);
                }
                catch(Exception  ex){
                    System.out.println("Couldn't find link"); 
                }
            }
        });
        link.setEnabled(true);
        
        airBnBinfo= new JTextArea(
            "AirBnB was created in 2008 and is designed for people rent or lease homes on a short basis. " +
            "The sort of acconomdation you can pick through the website can vary from cottages to apartments. " + 
            "AirBnB is now operating in 191 different countries giving people a much needed alternative to conventional accomodation (hotels/hostels)");   
        airBnBinfo.setFont(new Font("sansserif",0,16));
        airBnBinfo.setEnabled(true);
        airBnBinfo.setLineWrap(true);
        airBnBinfo.setWrapStyleWord(true);
        airBnBinfo.setEditable(false);

        airbnbphoto = new JLabel("", SwingConstants.CENTER);
       
        airbnbphoto.setForeground(new Color(0,0,0));
        airbnbphoto.setFont(new Font("sansserif",0,12));
        airbnbphoto.setIcon(new ImageIcon("airbnbnew.png"));
        airbnbphoto.setEnabled(true);
        
        cardInfo.add(airbnbphoto); 
        cardInfo.add(airBnBlabel);
        cardInfo.add(airBnBinfo); 
        cardInfo.add(link);
    }
    
    /**
     * @return cardInfo 
     */
    public JPanel getPanel() 
    {
        return cardInfo; 
    }
}
