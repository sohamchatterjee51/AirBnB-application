import javax.swing.UIManager.LookAndFeelInfo;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import javax.swing.border.*;
import javax.swing.*;
import java.util.*;

/**
 * Displays a range of statistics for all properties within a specific price range.
 * 
 * @author Muhsin Kumbay, Soham Chatterjee, Rahul Patel, Mishal Almazidi
 * @version 27/03/18
 */
public class StatisticScreen
{
    private JPanel cardStats;
    private JPanel topLeft;
    private JPanel topRight;
    private JPanel bottomLeft;
    private JPanel bottomRight;
    private JButton[] statsButtons; 
    private JLabel[] statLabels;
    private Statistics stats; 
    private JPanel[] cards;
    
    /**
     * Constructor for objects of class WelcomeScreen
     */
    public StatisticScreen(Statistics stats)
    {   
        this.stats = stats;
        createPanel();
    }
    
    public void createPanel() 
    {
        // create components 
        statsButtons = new JButton[8];           
        cards = new JPanel[4]; 
        statLabels = new JLabel[8]; 
        
        cardStats = new JPanel(new GridLayout(2, 2, 5, 5)); 
        
        topLeft = new JPanel(new BorderLayout());
        topRight = new JPanel(new BorderLayout());
        bottomLeft = new JPanel(new BorderLayout());
        bottomRight = new JPanel(new BorderLayout());
        
        cards[0] = new JPanel(new CardLayout());
        cards[1] = new JPanel(new CardLayout());
        cards[2] = new JPanel(new CardLayout()); 
        cards[3] = new JPanel(new CardLayout());
                
        for(int i = 0; i < 8; i++) 
        {
            if (i % 2 == 0) {
                statsButtons[i] = new JButton("<");
            }
            else {
                statsButtons[i] = new JButton(">");
            }
        }
        
        String newline = System.getProperty("line.separator");
        
        statLabels[0] = new JLabel("<html> Number of available properties: <br/>" + "" + stats.numberAvailableProperties() + "</html>" , SwingConstants.CENTER);
        statLabels[1] = new JLabel("<html> Average number of reviews per property: <br/>" + newline + stats.averageNumberOfReviews() + "</html>", SwingConstants.CENTER);
        statLabels[2] = new JLabel("<html> Average availability(days)/year: <br/>" + newline + stats.averageAvailability() + "</html>", SwingConstants.CENTER); 
        statLabels[3] = new JLabel("<html> Number of entire rooms/apt: <br/>" + newline + stats.amountRoomOrApartment() + "</html>", SwingConstants.CENTER);
        statLabels[4] = new JLabel("<html> Average latitude of properties: <br/>" + newline + stats.averageLatitude() + "</html>", SwingConstants.CENTER); 
        statLabels[5] = new JLabel("<html> Average longitude of properties: <br/>" + newline + stats.averageLongitude() + "</html>", SwingConstants.CENTER); 
        statLabels[6] = new JLabel("<html> Priciest neigbhourhood: <br/>" + newline + stats.mostExpensiveNeighbourhood() + "</html>", SwingConstants.CENTER);
        statLabels[7] = new JLabel("<html> Average minimum number of nights: <br/>" + newline + stats.averageNumberOfNight() + "</html>", SwingConstants.CENTER); 
        
        cards[0].add(statLabels[0]); 
        cards[0].add(statLabels[1]);
        
        cards[1].add(statLabels[2]); 
        cards[1].add(statLabels[3]);
        
        cards[2].add(statLabels[4]); 
        cards[2].add(statLabels[5]); 
        
        cards[3].add(statLabels[6]);
        cards[3].add(statLabels[7]);
          
        //TopLeft
        
        topLeft.add(statsButtons[0], BorderLayout.WEST); // Add to west of panel
        topLeft.add(statsButtons[1], BorderLayout.EAST); // Add to east of panel
        topLeft.add(cards[0], BorderLayout.CENTER);
        
        topLeft.setBorder(new EtchedBorder());
        
        //TopRight
        
        topRight.add(statsButtons[2], BorderLayout.WEST); // Add to west of panel
        topRight.add(statsButtons[3], BorderLayout.EAST); // Add to east of panel
        topRight.add(cards[1], BorderLayout.CENTER);
        
        topRight.setBorder(new EtchedBorder());
        
        //BotLeft
        
        bottomLeft.add(statsButtons[4], BorderLayout.WEST); // Add to west of panel
        bottomLeft.add(statsButtons[5], BorderLayout.EAST); // Add to east of panel
        bottomLeft.add(cards[2], BorderLayout.CENTER);
        
        bottomLeft.setBorder(new EtchedBorder());
        
        //BotRight
        
        bottomRight.add(statsButtons[6], BorderLayout.WEST); // Add to west of panel
        bottomRight.add(statsButtons[7], BorderLayout.EAST); // Add to east of panel
        bottomRight.add(cards[3], BorderLayout.CENTER);
        
        bottomRight.setBorder(new EtchedBorder());
       
        //add componenets
        cardStats.add(topLeft);
        cardStats.add(topRight);
        cardStats.add(bottomLeft);
        cardStats.add(bottomRight);
        
        cardStats.revalidate(); 
        cardStats.repaint();
        
        statsButtons[0].addActionListener((ActionEvent ev) -> {moveLeft(cards[0]);});
        statsButtons[1].addActionListener((ActionEvent ev) -> {moveRight(cards[0]);});
        
        statsButtons[2].addActionListener((ActionEvent ev) -> {moveLeft(cards[1]);});
        statsButtons[3].addActionListener((ActionEvent ev) -> {moveRight(cards[1]);});
        
        statsButtons[4].addActionListener((ActionEvent ev) -> {moveLeft(cards[2]);});
        statsButtons[5].addActionListener((ActionEvent ev) -> {moveRight(cards[2]);});
        
        statsButtons[6].addActionListener((ActionEvent ev) -> {moveLeft(cards[3]);});
        statsButtons[7].addActionListener((ActionEvent ev) -> {moveRight(cards[3]);});
    }
    
    public JPanel getPanel() 
    {
        return cardStats; 
    }
    
    // Move one panel to the right 
    private void moveRight(JPanel cards) 
    {
        CardLayout c1 = (CardLayout)(cards.getLayout()); 
        c1.next(cards);
    }
    
    // Move one panel to the left
    private void moveLeft(JPanel cards) 
    {
        CardLayout c1 = (CardLayout)(cards.getLayout()); 
        c1.previous(cards);
    }
    
    /**
     * Updates the statistic text to represent new price range 
     * @param Statistic
     */
    public void updateText(int fromPrice, int toPrice)
    {   
        Statistics tempStats = new Statistics(fromPrice, toPrice);
        statLabels[0].setText("<html> Number of available properties: <br/>" + tempStats.numberAvailableProperties() + "</html>");
        statLabels[1].setText("<html> Average number of reviews per property: <br/>" + tempStats.averageNumberOfReviews() + "</html>");
        statLabels[2].setText("<html> Average availability(days)/year: <br/>" + tempStats.averageAvailability() + "</html>"); 
        statLabels[3].setText("<html> Number of entire rooms/apt: <br/>" + tempStats.amountRoomOrApartment() + "</html>");
        statLabels[4].setText("<html> Average latitude of properties: <br/>" + tempStats.averageLatitude() + "</html>"); 
        statLabels[5].setText("<html> Average longitude of properties: <br/>" + tempStats.averageLongitude() + "</html>"); 
        statLabels[6].setText("<html> Priciest neigbhourhood: <br/>" + tempStats.mostExpensiveNeighbourhood() + "</html>");
        statLabels[7].setText("<html> Average minimum number of nights: <br/>" + tempStats.averageNumberOfNight() + "</html>"); 
    }
}

